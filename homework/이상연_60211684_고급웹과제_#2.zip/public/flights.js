//  고급웹프로그래밍 과제#2 이상연 60211684 

const flights = [
    {id : '1', airline: 'KoreanAir', to: 'Sydney', gate : 37},
    {id : '2', airline: 'Delta', to: 'Tokyo', gate : 102},
    {id : '3', airline: 'KoreanAir', to: 'Paris', gate : 46},
    {id : '4', airline: 'AirFrance', to: 'Paris', gate : 15},
]

module.exports = flights;