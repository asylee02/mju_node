//  고급웹프로그래밍 과제#2 이상연 60211684 

const express = require("express");
const morgan = require("morgan");
const path = require("path");
const fs = require("fs").promises;
const flights = require("../public/flights.js");

const router = express.Router();
let flights_len = flights.length; // flights.length 대신 let으로 변경하여 동기화 유지

// 출발 항공편 목록 페이지 렌더링
router.get("/", (req, res) => {
  const username = req.session.userid;
  console.log(flights);
  res.render("depart", { title: "depart", name: username, flights: flights });
});

// 새로운 항공편 추가
router.post("/", (req, res) => {
  const username = req.session.userid;
  console.log(req.body);
  flights_len += 1; // flights_len 값 증가
  flights.push({
    id: flights_len,
    airline: req.body.airline,
    to: req.body.to,
    gate: req.body.gate,
  });
  res.render("depart", { title: "depart", name: username, flights: flights });
});

// 항공편 삭제
router.delete("/:id", (req, res) => {
  const username = req.session.userid;
  const id = req.params.id;
  const index = flights.findIndex((flight) => flight.id === id);
  flights.splice(index, 1);
  res.render("depart", { title: "deaprt", name: username, flights: flights });
});

// 항공편 수정
router.put("/:id", (req, res) => {
  const username = req.session.userid;
  const id = Number(req.params.id);
  const airline = req.body.airline;
  const to = req.body.to;
  const gate = Number(req.body.gate);
  const index = flights.findIndex((flight) => flight.id === id);

  flights[index] = { id, airline, to, gate };
  console.log(flights);
  res.render("depart", { title: "depart", name: username, flights: flights });
});

// 오류 처리 미들웨어
router.use((err, req, res, next) => {
  console.error(err);
  res.status(500).send("서버 에러가 발생했습니다!");
});

module.exports = router;
